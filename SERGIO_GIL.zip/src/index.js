require("./reset.css");
require("./calculadora.css");
const { inicializaBotones } = require("./inicializaBotones");

inicializaBotones();