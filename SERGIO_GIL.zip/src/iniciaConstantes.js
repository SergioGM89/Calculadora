function getDisplay(){
    return document.querySelector("#display");;
}

function getLog(){
    return document.querySelector("#log");;
}

module.exports = {
    getDisplay,
    getLog, 
}
